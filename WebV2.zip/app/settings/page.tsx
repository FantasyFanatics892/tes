import { Separator } from "@/components/ui/separator"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Bell, User, Shield, Palette, Globe } from "lucide-react"

export default function SettingsPage() {
  return (
    <div className="container mx-auto p-4 space-y-6">
      <div className="flex flex-col gap-2">
        <h1 className="text-3xl font-bold tracking-tight">Pengaturan</h1>
        <p className="text-muted-foreground">Kelola preferensi dan pengaturan akun Anda.</p>
      </div>
      <Separator />

      <Tabs defaultValue="appearance" className="w-full">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="appearance" className="flex items-center gap-2">
            <Palette className="h-4 w-4" />
            <span className="hidden sm:inline">Tampilan</span>
          </TabsTrigger>
          <TabsTrigger value="account" className="flex items-center gap-2">
            <User className="h-4 w-4" />
            <span className="hidden sm:inline">Akun</span>
          </TabsTrigger>
          <TabsTrigger value="notifications" className="flex items-center gap-2">
            <Bell className="h-4 w-4" />
            <span className="hidden sm:inline">Notifikasi</span>
          </TabsTrigger>
          <TabsTrigger value="privacy" className="flex items-center gap-2">
            <Shield className="h-4 w-4" />
            <span className="hidden sm:inline">Privasi</span>
          </TabsTrigger>
          <TabsTrigger value="language" className="flex items-center gap-2">
            <Globe className="h-4 w-4" />
            <span className="hidden sm:inline">Bahasa</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="appearance" className="space-y-6 mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Tampilan</CardTitle>
              <CardDescription>Sesuaikan tampilan aplikasi sesuai preferensi Anda.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div>
                  <h3 className="text-lg font-medium">Tema</h3>
                  <p className="text-sm text-muted-foreground">Pilih tema yang ingin Anda gunakan.</p>
                </div>
                <RadioGroup defaultValue="system">
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="light" id="light" />
                    <Label htmlFor="light">Terang</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="dark" id="dark" />
                    <Label htmlFor="dark">Gelap</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="system" id="system" />
                    <Label htmlFor="system">Sistem</Label>
                  </div>
                </RadioGroup>
              </div>

              <Separator />

              <div className="space-y-4">
                <div>
                  <h3 className="text-lg font-medium">Warna Aksen</h3>
                  <p className="text-sm text-muted-foreground">Pilih warna aksen untuk aplikasi.</p>
                </div>
                <div className="grid grid-cols-3 gap-2">
                  <Button
                    variant="outline"
                    className="h-10 w-full border-2 border-purple-500 bg-purple-500/10 hover:bg-purple-500/20"
                  >
                    Ungu
                  </Button>
                  <Button
                    variant="outline"
                    className="h-10 w-full border-2 border-blue-500 bg-blue-500/10 hover:bg-blue-500/20"
                  >
                    Biru
                  </Button>
                  <Button
                    variant="outline"
                    className="h-10 w-full border-2 border-green-500 bg-green-500/10 hover:bg-green-500/20"
                  >
                    Hijau
                  </Button>
                </div>
              </div>

              <Separator />

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="font-size">Ukuran Font</Label>
                  <p className="text-sm text-muted-foreground">Sesuaikan ukuran font untuk kemudahan membaca.</p>
                </div>
                <Select defaultValue="medium">
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Pilih ukuran" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="small">Kecil</SelectItem>
                    <SelectItem value="medium">Sedang</SelectItem>
                    <SelectItem value="large">Besar</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Separator />

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="animations">Animasi</Label>
                  <p className="text-sm text-muted-foreground">Aktifkan atau nonaktifkan animasi UI.</p>
                </div>
                <Switch id="animations" defaultChecked />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="account" className="space-y-6 mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Informasi Akun</CardTitle>
              <CardDescription>Perbarui informasi profil Anda.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Nama Lengkap</Label>
                  <Input id="name" placeholder="Nama Lengkap" defaultValue="Siswa TKJ" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input id="email" type="email" placeholder="Email" defaultValue="siswa@tkj2.sch.id" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="nis">NIS</Label>
                  <Input id="nis" placeholder="Nomor Induk Siswa" defaultValue="12345" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="phone">Nomor Telepon</Label>
                  <Input id="phone" placeholder="Nomor Telepon" defaultValue="08123456789" />
                </div>
              </div>

              <Separator />

              <div className="space-y-2">
                <Label htmlFor="bio">Bio</Label>
                <textarea
                  id="bio"
                  className="w-full min-h-[100px] rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                  placeholder="Ceritakan sedikit tentang diri Anda"
                  defaultValue="Siswa kelas 10 TKJ-2 yang bersemangat mempelajari jaringan komputer dan pemrograman."
                />
              </div>

              <div className="flex justify-end">
                <Button>Simpan Perubahan</Button>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Keamanan</CardTitle>
              <CardDescription>Kelola keamanan akun Anda.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="current-password">Password Saat Ini</Label>
                <Input id="current-password" type="password" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="new-password">Password Baru</Label>
                <Input id="new-password" type="password" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="confirm-password">Konfirmasi Password</Label>
                <Input id="confirm-password" type="password" />
              </div>

              <div className="flex justify-end">
                <Button>Ubah Password</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="notifications" className="space-y-6 mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Pengaturan Notifikasi</CardTitle>
              <CardDescription>Kelola preferensi notifikasi Anda.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Email</h3>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="email-announcements">Pengumuman</Label>
                    <Switch id="email-announcements" defaultChecked />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label htmlFor="email-assignments">Tugas Baru</Label>
                    <Switch id="email-assignments" defaultChecked />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label htmlFor="email-forum">Balasan Forum</Label>
                    <Switch id="email-forum" defaultChecked />
                  </div>
                </div>
              </div>

              <Separator />

              <div className="space-y-4">
                <h3 className="text-lg font-medium">Aplikasi</h3>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="app-announcements">Pengumuman</Label>
                    <Switch id="app-announcements" defaultChecked />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label htmlFor="app-assignments">Tugas Baru</Label>
                    <Switch id="app-assignments" defaultChecked />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label htmlFor="app-forum">Balasan Forum</Label>
                    <Switch id="app-forum" defaultChecked />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label htmlFor="app-deadline">Pengingat Deadline</Label>
                    <Switch id="app-deadline" defaultChecked />
                  </div>
                </div>
              </div>

              <Separator />

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Frekuensi Notifikasi</Label>
                  <p className="text-sm text-muted-foreground">Seberapa sering Anda ingin menerima notifikasi.</p>
                </div>
                <Select defaultValue="realtime">
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Pilih frekuensi" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="realtime">Real-time</SelectItem>
                    <SelectItem value="daily">Harian</SelectItem>
                    <SelectItem value="weekly">Mingguan</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="privacy" className="space-y-6 mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Privasi</CardTitle>
              <CardDescription>Kelola pengaturan privasi akun Anda.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Visibilitas Profil</h3>
                <RadioGroup defaultValue="classmates">
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="public" id="public" />
                    <Label htmlFor="public">Publik (Semua pengguna)</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="classmates" id="classmates" />
                    <Label htmlFor="classmates">Teman Sekelas</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="private" id="private" />
                    <Label htmlFor="private">Privat (Hanya guru)</Label>
                  </div>
                </RadioGroup>
              </div>

              <Separator />

              <div className="space-y-4">
                <h3 className="text-lg font-medium">Aktivitas</h3>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="show-online-status">Tampilkan Status Online</Label>
                    <Switch id="show-online-status" defaultChecked />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label htmlFor="show-last-seen">Tampilkan Terakhir Dilihat</Label>
                    <Switch id="show-last-seen" defaultChecked />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label htmlFor="show-read-receipts">Tampilkan Tanda Dibaca</Label>
                    <Switch id="show-read-receipts" defaultChecked />
                  </div>
                </div>
              </div>

              <Separator />

              <div className="space-y-4">
                <h3 className="text-lg font-medium">Data</h3>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Unduh Data Saya</Label>
                      <p className="text-sm text-muted-foreground">Unduh salinan data Anda dari platform ini.</p>
                    </div>
                    <Button variant="outline">Unduh</Button>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Hapus Akun</Label>
                      <p className="text-sm text-muted-foreground">Hapus akun dan semua data Anda secara permanen.</p>
                    </div>
                    <Button variant="destructive">Hapus</Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="language" className="space-y-6 mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Bahasa dan Regional</CardTitle>
              <CardDescription>Sesuaikan pengaturan bahasa dan regional.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div>
                  <h3 className="text-lg font-medium">Bahasa Aplikasi</h3>
                  <p className="text-sm text-muted-foreground">Pilih bahasa yang ingin Anda gunakan.</p>
                </div>
                <Select defaultValue="id">
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Pilih bahasa" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="id">Bahasa Indonesia</SelectItem>
                    <SelectItem value="en">English</SelectItem>
                    <SelectItem value="jw">Basa Jawa</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Separator />

              <div className="space-y-4">
                <div>
                  <h3 className="text-lg font-medium">Format Tanggal</h3>
                  <p className="text-sm text-muted-foreground">Pilih format tanggal yang ingin Anda gunakan.</p>
                </div>
                <RadioGroup defaultValue="dmy">
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="dmy" id="dmy" />
                    <Label htmlFor="dmy">DD/MM/YYYY (31/12/2025)</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="mdy" id="mdy" />
                    <Label htmlFor="mdy">MM/DD/YYYY (12/31/2025)</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="ymd" id="ymd" />
                    <Label htmlFor="ymd">YYYY/MM/DD (2025/12/31)</Label>
                  </div>
                </RadioGroup>
              </div>

              <Separator />

              <div className="space-y-4">
                <div>
                  <h3 className="text-lg font-medium">Format Waktu</h3>
                  <p className="text-sm text-muted-foreground">Pilih format waktu yang ingin Anda gunakan.</p>
                </div>
                <RadioGroup defaultValue="24h">
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="12h" id="12h" />
                    <Label htmlFor="12h">12 jam (1:30 PM)</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="24h" id="24h" />
                    <Label htmlFor="24h">24 jam (13:30)</Label>
                  </div>
                </RadioGroup>
              </div>

              <Separator />

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Zona Waktu</Label>
                  <p className="text-sm text-muted-foreground">Pilih zona waktu yang ingin Anda gunakan.</p>
                </div>
                <Select defaultValue="asia-jakarta">
                  <SelectTrigger className="w-[250px]">
                    <SelectValue placeholder="Pilih zona waktu" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="asia-jakarta">Asia/Jakarta (GMT+7)</SelectItem>
                    <SelectItem value="asia-makassar">Asia/Makassar (GMT+8)</SelectItem>
                    <SelectItem value="asia-jayapura">Asia/Jayapura (GMT+9)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

