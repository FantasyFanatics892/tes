import Image from "next/image"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { useTranslations } from "next-intl"

export default function StrukturKelas() {
  const t = useTranslations("classStructure")
  const common = useTranslations("common")

  const strukturKelas = [
    {
      jabatan: t("roles.classTeacher"),
      nama: "Budi Santoso, S.Kom",
      foto: "/placeholder.svg?height=200&width=200",
      deskripsi: "Guru Jaringan Dasar dan Wali Kelas TKJ-2",
    },
    {
      jabatan: t("roles.classPresident"),
      nama: "Ahmad Rizki",
      foto: "/placeholder.svg?height=200&width=200",
      deskripsi: "Siswa kelas 10 TKJ-2",
    },
    {
      jabatan: t("roles.vicePresident"),
      nama: "Siti Nurhaliza",
      foto: "/placeholder.svg?height=200&width=200",
      deskripsi: "Siswa kelas 10 TKJ-2",
    },
    {
      jabatan: t("roles.secretary"),
      nama: "Dewi Anggraini",
      foto: "/placeholder.svg?height=200&width=200",
      deskripsi: "Siswa kelas 10 TKJ-2",
    },
    {
      jabatan: t("roles.treasurer"),
      nama: "Rini Susanti",
      foto: "/placeholder.svg?height=200&width=200",
      deskripsi: "Siswa kelas 10 TKJ-2",
    },
    {
      jabatan: t("roles.cleaningSection"),
      nama: "Dimas Pratama",
      foto: "/placeholder.svg?height=200&width=200",
      deskripsi: "Siswa kelas 10 TKJ-2",
    },
    {
      jabatan: t("roles.securitySection"),
      nama: "Andi Saputra",
      foto: "/placeholder.svg?height=200&width=200",
      deskripsi: "Siswa kelas 10 TKJ-2",
    },
    {
      jabatan: t("roles.administrator"),
      nama: "Reza Mahendra",
      foto: "/placeholder.svg?height=200&width=200",
      deskripsi: "Siswa kelas 10 TKJ-2, pengelola website kelas",
    },
  ]

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-2">
        <h1 className="text-3xl font-bold tracking-tight">{t("title")}</h1>
        <p className="text-muted-foreground">{t("description")}</p>
      </div>

      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        {strukturKelas.map((anggota) => (
          <Card key={anggota.jabatan} className="overflow-hidden">
            <div className="aspect-square w-full overflow-hidden">
              <Image
                src={anggota.foto || "/placeholder.svg"}
                alt={anggota.nama}
                width={400}
                height={400}
                className="h-full w-full object-cover transition-transform hover:scale-105"
              />
            </div>
            <CardHeader className="p-4">
              <CardTitle className="text-xl">{anggota.nama}</CardTitle>
              <CardDescription className="font-medium text-primary">{anggota.jabatan}</CardDescription>
            </CardHeader>
            <CardContent className="p-4 pt-0">
              <p className="text-sm text-muted-foreground">{anggota.deskripsi}</p>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

