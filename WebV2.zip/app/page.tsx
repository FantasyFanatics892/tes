import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { CalendarDays, FileText, GraduationCap, MessageSquare, Bell } from "lucide-react"
import Image from "next/image"

export default function Home() {
  return (
    <div className="container mx-auto p-4 space-y-6">
      {/* Hero Section */}
      <section className="relative rounded-xl overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-purple-900/90 to-black/70 z-10" />
        <Image
          src="/placeholder.svg?height=400&width=1200"
          alt="TKJ-2 Class"
          width={1200}
          height={400}
          className="w-full h-[400px] object-cover"
        />
        <div className="absolute inset-0 z-20 flex flex-col justify-center p-8">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">Selamat Datang di Kelas TKJ-2</h1>
          <p className="text-lg md:text-xl text-white/90 max-w-2xl mb-6">
            Portal pembelajaran dan komunikasi untuk siswa kelas 10 TKJ-2 di sekolah kejuruan
          </p>
          <div className="flex flex-wrap gap-4">
            <Button size="lg" className="bg-purple-600 hover:bg-purple-700">
              Lihat Materi Pelajaran
            </Button>
            <Button size="lg" variant="outline" className="text-white border-white hover:bg-white/10">
              Forum Diskusi
            </Button>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column - Announcements & Calendar */}
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Bell className="h-5 w-5 text-purple-500" />
                Pengumuman Terbaru
              </CardTitle>
              <CardDescription>Informasi penting untuk kelas TKJ-2</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {[1, 2, 3].map((i) => (
                <div key={i} className="border-l-4 border-purple-500 pl-4 py-2">
                  <h3 className="font-medium">Pengumpulan Tugas Jaringan Dasar</h3>
                  <p className="text-sm text-muted-foreground">
                    Batas waktu pengumpulan tugas Jaringan Dasar diperpanjang hingga 20 Februari 2025
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">15 Februari 2025</p>
                </div>
              ))}
            </CardContent>
            <CardFooter>
              <Button variant="ghost" size="sm" className="ml-auto">
                Lihat Semua Pengumuman
              </Button>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CalendarDays className="h-5 w-5 text-purple-500" />
                Kalender Akademik
              </CardTitle>
              <CardDescription>Jadwal kegiatan dan deadline penting</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="flex gap-4 items-start">
                    <div className="bg-purple-100 dark:bg-purple-950 text-purple-700 dark:text-purple-300 p-2 rounded-md text-center min-w-16">
                      <div className="text-xs font-medium">FEB</div>
                      <div className="text-xl font-bold">{15 + i}</div>
                    </div>
                    <div>
                      <h4 className="font-medium">Ujian Praktikum Pemrograman Dasar</h4>
                      <p className="text-sm text-muted-foreground">Lab Komputer 2 • 08:00 - 10:30</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
            <CardFooter>
              <Button variant="ghost" size="sm" className="ml-auto">
                Lihat Kalender Lengkap
              </Button>
            </CardFooter>
          </Card>
        </div>

        {/* Right Column - Quick Access & Stats */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Akses Cepat</CardTitle>
              <CardDescription>Fitur yang sering digunakan</CardDescription>
            </CardHeader>
            <CardContent className="grid grid-cols-2 gap-4">
              <Button variant="outline" className="h-24 flex flex-col gap-2 justify-center">
                <FileText className="h-6 w-6 text-purple-500" />
                <span>Materi</span>
              </Button>
              <Button variant="outline" className="h-24 flex flex-col gap-2 justify-center">
                <GraduationCap className="h-6 w-6 text-purple-500" />
                <span>Tugas</span>
              </Button>
              <Button variant="outline" className="h-24 flex flex-col gap-2 justify-center">
                <MessageSquare className="h-6 w-6 text-purple-500" />
                <span>Forum</span>
              </Button>
              <Button variant="outline" className="h-24 flex flex-col gap-2 justify-center">
                <CalendarDays className="h-6 w-6 text-purple-500" />
                <span>Jadwal</span>
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Aktivitas Kelas</CardTitle>
              <CardDescription>Statistik dan aktivitas terkini</CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="tugas">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="tugas">Tugas</TabsTrigger>
                  <TabsTrigger value="diskusi">Diskusi</TabsTrigger>
                  <TabsTrigger value="materi">Materi</TabsTrigger>
                </TabsList>
                <TabsContent value="tugas" className="space-y-4 pt-4">
                  <div className="flex justify-between items-center">
                    <span>Tugas Selesai</span>
                    <span className="font-medium">24/30</span>
                  </div>
                  <div className="w-full bg-muted rounded-full h-2.5">
                    <div className="bg-purple-600 h-2.5 rounded-full" style={{ width: "80%" }}></div>
                  </div>
                  <div className="text-sm text-muted-foreground">6 tugas belum diselesaikan</div>
                </TabsContent>
                <TabsContent value="diskusi" className="pt-4">
                  <div className="text-sm">
                    <p>Forum paling aktif:</p>
                    <ul className="list-disc list-inside space-y-2 mt-2">
                      <li>Pemrograman Dasar (32 posts)</li>
                      <li>Jaringan Dasar (18 posts)</li>
                      <li>Keamanan Jaringan (12 posts)</li>
                    </ul>
                  </div>
                </TabsContent>
                <TabsContent value="materi" className="pt-4">
                  <div className="text-sm">
                    <p>Materi terbaru:</p>
                    <ul className="list-disc list-inside space-y-2 mt-2">
                      <li>Pengenalan Routing (Jaringan Dasar)</li>
                      <li>Algoritma Sorting (Pemrograman Dasar)</li>
                      <li>Firewall Configuration (Keamanan Jaringan)</li>
                    </ul>
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

